COLMAP v4 - Failed Run Log Collection
Source: summary(2).csv
Scope: 16 objects and 35 failed configurations.

1. Extract this ZIP archive.
2. Open an object ID folder, then its 18, 36, or 72 subfolder.
3. Read FAILURE_DETAILS_AND_LOG_CHECKLIST.txt.
4. Copy the requested logs and result.json from the exact source attempt into that subfolder.
5. Once collected, compress the entire folder and share it for diagnosis.

Only configurations marked failed are included. Completed runs with partial registration are excluded.
Do not include input images, database.db, dense directories, or large PLY files.
Original source paths are preserved. Non-English product titles are omitted; object IDs, item IDs, and categories identify each object.
No actual logs are included in this template.
